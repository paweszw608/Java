package pl.polsl.lab2;

import static java.lang.System.*;

/**
 * VarArgsDemo feature.
 *
 * @author Gall Anonim
 * @version 1.0
 */
public class VarArgsDemo {

    public static void main(String[] args) {

        out.println(sum());
        out.println(sum(1));
        out.println(sum(1, 7, 5, 23, 4));
        out.println(sum(new int[]{3, 7, 2, 5}));

        int[] tab = new int[3];
        tab[0] = 66;
        out.println(sum(tab));
    }

    static int sum(int... args) { // nie trzeba przekazywac tablicy, nie mozna przekazac nulla, 
        //nie trzeba jawnie deklarowac tablicy zeby przekazac
        int suma = 0;
        for (int i = 0; i < args.length; i++) {
            suma += args[i];
        }
        return suma;
    }
}
