package pl.polsl.java.lab2.test;

import pl.polsl.java.lab2.bank.*;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.junit.rules.ExpectedException;

/**
 * Test case of account methods
 *
 * @author Gall Anonim
 * @version 1.1
 */
public class AccountTest {

    Account account;

    @Before
    public void setup() {
        account = new Account(100);
    }

    @Test
    public void testPayment() {

        try {
            account.payment(100);
            assertEquals("Payment 100", account.getBalance(), 200, 0.01);

            account.payment(0);
            fail("An exception should be thrown when the amount equals zero");
        } catch (BankException e) {
        }

        try {
            account.payment(-30);
            fail("An exception should be thrown when the amount is non-positive");
        } catch (BankException e) {
        }
    }

    @Test
    public void testMonthlyCapitalisation() {
        account.monthlyCapitalisation(3);
        assertEquals("Capitalisation 3% from 100",
                account.getBalance(), (100 + 100 * (3.0 / 100 / 12)), 0.01);
        

        account = new Account(0);
        account.monthlyCapitalisation(3);
        assertEquals("Capitalisation 3% from empty account",
                account.getBalance(), 0, 0.01);

        account = new Account(100);
        account.monthlyCapitalisation(0);
        assertEquals("Capitalisation 0% from 100",
                account.getBalance(), 100, 0.01);

        account = new Account(100);
        account.monthlyCapitalisation(-3);
        assertEquals("Capitalisation -3% from 100",
                account.getBalance(), 100 - 100 * (3.0 / 100 / 12), 0.01);
    }

    @Test
    public void testPayoff() {
        // to implement
    }

// -------------------------------------------------------------
// Various approaches to exception test
// -------------------------------------------------------------
    @Test(expected = BankException.class)
    public void theShortestTestOfException() throws Exception {
        account.payment(-30);
    }

    @Test
    public void simpleTestOfException() {
        try {
            account.payment(-30);
            fail("An exception should be thrown when the amount is non-positive");
        } catch (BankException e) {
        }
    }

    @Test
    public void extendedTestOfException() {
        try {
            account.payment(-30);
            fail("An exception should be thrown when the amount is non-positive");
        } catch (BankException e) {
            assertEquals("Balance shouldn't be changed!", 100, account.getBalance(), 0.01);
            assertTrue("Unexpected message!", e.getMessage().contains("Payment"));
        }
    }

    @Test
    public void elegantTestOfException() {
        Exception exception = null;
        try {
            account.payment(-30);
        } catch (BankException e) {
            exception = e;
        }
        assertThat("Wrong type of the exception!",exception, is(instanceOf(BankException.class)));
        assertThat("Unexpected message!", exception.getMessage(), startsWith("Payment"));
        assertThat("Balance shouldn't be changed!", account.getBalance(), is(100f));
    }

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Test
    public void testOfExceptionWithRule() throws Exception {

        expectedException.expect(BankException.class);
        expectedException.expectMessage(startsWith("Payment"));
        account.payment(-30);
    }
   
}
