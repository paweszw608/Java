package pl.polsl.lab.streams;

import java.io.*;
import java.util.*;

public class RhymingWords {

    public static void main(String[] args) {

        List<String> listOfWords = new ArrayList<String>();
        try( BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("words.txt")))) {
            String tmpWord;
            while ((tmpWord = in.readLine()) != null) {
                listOfWords.add(tmpWord);
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
        long startTime = Calendar.getInstance().getTimeInMillis();
        reverseWords(listOfWords);
        Collections.sort(listOfWords);
        reverseWords(listOfWords);
        long finishTime = Calendar.getInstance().getTimeInMillis();

        for (String word : listOfWords) {
            System.out.println(word);
        }
        System.out.println("Operation time: " + (finishTime - startTime));
    }

    private static void reverseWords(List<String> list) {
        StringBuffer stringBuffer;
        for (int i = 0; i < list.size(); i++) {
            String word = list.get(i);
            stringBuffer = new StringBuffer(word);
            list.set(i, stringBuffer.reverse().toString());
        }

    }
}
