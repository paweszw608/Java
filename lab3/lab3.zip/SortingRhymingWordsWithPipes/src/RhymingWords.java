/*
 * Copyright (c) 1995-1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
import java.io.*;
import java.util.Calendar;

public class RhymingWords {

    public static void main(String[] args) {

        try (DataInputStream words = new DataInputStream(new FileInputStream("words.txt"))) {

            // do the reversing and sorting
            long startTime = Calendar.getInstance().getTimeInMillis();
            InputStream rhymedWords = reverse(sort(reverse(words)));
            long finishTime = Calendar.getInstance().getTimeInMillis();

            // write new list to standard out
            DataInputStream dis = new DataInputStream(rhymedWords);
            String input;

            while ((input = dis.readLine()) != null) {
                System.out.println(input);
            }
            System.out.println("Operation time: " + (finishTime - startTime));
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }

    }

    public static InputStream reverse(InputStream source) throws IOException {
        
        DataInputStream dis = new DataInputStream(source);
        PipedOutputStream pos = new PipedOutputStream();
        PipedInputStream pis = new PipedInputStream(pos);
        PrintStream ps = new PrintStream(pos);
        new WriteReversedThread(ps, dis).start();
        return pis;
    }

    public static InputStream sort(InputStream source) throws IOException {

        DataInputStream dis = new DataInputStream(source);
        PipedOutputStream pos = new PipedOutputStream();
        PipedInputStream pis = new PipedInputStream(pos);
        PrintStream ps = new PrintStream(pos);
        new SortThread(ps, dis).start();

        return pis;
    }
}

