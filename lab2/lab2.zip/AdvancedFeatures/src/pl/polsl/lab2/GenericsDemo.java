package pl.polsl.lab2;

import java.util.*;

/**
 * GenericsDemo features
 *
 * @author Gall Anonim
 * @version 1.1
 */
public class GenericsDemo {

    @SuppressWarnings("unchecked")
    public static void main(String[] args) {

        // standard collection
        Vector vector = new Vector();
        vector.add(66);
        vector.add(13);
        // The compiler doesn't check the type of argument 
        vector.add("cat");
        int sum = 0;
        for (Object element : vector) {
            sum += (Integer) element;
        }
        System.out.println("Sum = " + sum);

        // Type-safe collection  
        Vector<Integer> safeVector = new Vector<>();
        safeVector.add(66); // 66 -> spakowane do Integera
        safeVector.add(13);
        // The compiler checks the type of argument. Uncomment next line! 
        // safeVector.add("cat");
        for (int element : safeVector) { 
            sum += element; // elementy z safeVector wypakowywane do int'a
        }
        System.out.println("Sum = " + sum);

        // own generic type
        Box<String> stringBox = new Box<>();
        NumberBox<Integer> numberBox = new NumberBox<>();
        numberBox.add(13);
        numberBox.add(7);
        System.out.println("sum = " + numberBox.sum());

        //NumberBox<String> stringBoxOfNumberBox = new NumberBox<String>();
       
        // test mojego kontenera
        MyContainer<String> cont= new MyContainer<>();
        cont.add("OK");
        
        
       
        
    }
}

class Box<T> {

    List<T> contents;
}

class NumberBox<N extends Number> { // N super Number (ale wtedy jest odwrotnie(?))

    List<N> contents; // index aktualnego elementu

    NumberBox() {
        contents = new LinkedList<>();
    }

    public void add(N obj) {
        contents.add(obj);
    }

    public N get(int index) {
        return contents.get(index);
    }

    public double sum() {
        double total = 0;
        Iterator<N> i = contents.iterator();
        while (i.hasNext()) {
            total += ((Integer) i.next()).doubleValue();
        }
        return total;
    }
}

class MyContainer<T> implements Iterable<T>, Iterator<T>{

    ArrayList<T> contents;
    private int index = 0;
    
    MyContainer(){
        contents = new ArrayList<>();
    }
    public void add(T elem){
        contents.add(elem);
    }
    @Override
    public Iterator<T> iterator() {
        index = 0;
        return this;
    }
    @Override
    public boolean hasNext() {
        return (index < contents.size());
    }

    @Override
    public T next() {
        return contents.get(index++);
    }
    
    @Override
    public void remove() {
        contents.remove(index);
        index--;
    }
    
}