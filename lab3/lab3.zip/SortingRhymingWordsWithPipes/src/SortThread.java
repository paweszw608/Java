/*
 * Copyright (c) 1995-1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class SortThread extends Thread {

    PrintStream ps;
    DataInputStream dis;

    SortThread(PrintStream ps, DataInputStream dis) {
        this.ps = ps;
        this.dis = dis;
    }

    public void run() {
        if (ps != null && dis != null) {
            try {
                List<String> listOfWords = new ArrayList<String>();
                String tmp;
                while ((tmp = dis.readLine()) != null) {
                    listOfWords.add(tmp);
                }
                Collections.sort(listOfWords);
                for (String word : listOfWords) {
                    ps.println(word);
                }
                ps.close();
                dis.close();
            } catch (IOException e) {
                System.out.println("WriteReversedThread run: " + e);
            }
        }
    }
}
