package pl.polsl.java.lab2.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * Sample test suite indicting the test engine and classes containg unit tests.
 *
 * @author Gall Anonim
 * @version 1.0
 */
@RunWith(Suite.class)
@SuiteClasses({
    AccountTest.class,
    TestAssert.class,
    TestSequence.class,})
public class TestSuite {
}
